import { CheckCircle2, CircleX, FileText } from "lucide-react";

export default function DocumentMatchingLevel({ initialResult = null }) {
  const result = initialResult;
  const documents = result?.results || [];

  return (
    <section className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
      <div className="border-b border-slate-100 p-5">
        <p className="text-xs font-bold uppercase tracking-wider text-sky-600">
          Level 1
        </p>
        <h3 className="mt-1 flex items-center gap-2 text-lg font-black text-slate-900">
          <FileText size={19} /> Document matching
        </h3>
        <p className="mt-1 text-sm text-slate-500">
          Each available required document earns 3 points.
        </p>
      </div>

      {!result ? (
        <p className="p-5 text-sm text-slate-500">
          Document matching results will appear after the eligibility analysis.
        </p>
      ) : (
        <div className="p-5">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3 rounded-xl bg-slate-50 p-4">
            <div>
              <p className="text-xs font-semibold text-slate-500">
                Total document score
              </p>
              <p className="mt-1 text-2xl font-black text-slate-900">
                {result.score}{" "}
                <span className="text-base font-semibold text-slate-400">
                  / {result.maximum_score}
                </span>
              </p>
            </div>
            <div className="text-right text-xs text-slate-500">
              <p>{result.matched_documents} matched</p>
              <p>{result.missing_documents} not matched</p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full min-w-[520px] text-left text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-xs uppercase tracking-wide text-slate-500">
                  <th className="px-3 py-3">Document</th>
                  <th className="px-3 py-3">Requirement</th>
                  <th className="px-3 py-3">Matching</th>
                  <th className="px-3 py-3 text-right">Score</th>
                </tr>
              </thead>
              <tbody>
                {documents.map((item) => (
                  <tr
                    key={
                      item.scholarship_document_id ?? item.document_name
                    }
                    className="border-b border-slate-100 last:border-0"
                  >
                    <td className="px-3 py-3 font-semibold text-slate-800">
                      {item.document_name}
                    </td>
                    <td className="px-3 py-3">
                      <span
                        className={
                          item.mandatory
                            ? "rounded-full bg-sky-50 px-2 py-1 text-xs font-semibold text-sky-700"
                            : "rounded-full bg-violet-50 px-2 py-1 text-xs font-semibold text-violet-700"
                        }
                      >
                        {item.mandatory ? "Mandatory" : "Optional"}
                      </span>
                    </td>
                    <td className="px-3 py-3">
                      <span
                        className={`inline-flex items-center gap-1.5 ${
                          item.status === "met"
                            ? "text-emerald-700"
                            : "text-rose-600"
                        }`}
                      >
                        {item.status === "met" ? (
                          <CheckCircle2 size={15} />
                        ) : (
                          <CircleX size={15} />
                        )}
                        {item.status === "met" ? "Matched" : "Not matched"}
                      </span>
                    </td>
                    <td className="px-3 py-3 text-right font-bold tabular-nums">
                      {item.score}
                    </td>
                  </tr>
                ))}
                <tr className="bg-slate-50 font-black text-slate-900">
                  <td className="px-3 py-3" colSpan={3}>
                    Total score
                  </td>
                  <td className="px-3 py-3 text-right tabular-nums">
                    {result.score}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          <p className="mt-4 text-xs leading-5 text-slate-500">
            Matching is based on the student's document checklist declaration.
            It does not verify the authenticity or contents of an uploaded
            document.
          </p>
        </div>
      )}
    </section>
  );
}
