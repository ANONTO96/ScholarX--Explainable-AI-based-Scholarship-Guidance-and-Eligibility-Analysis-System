import { Menu, X, ArrowRight, ChevronDown, LogOut, UserRound, } from "lucide-react";
import { useEffect, useState } from "react";
import { Link, NavLink } from "react-router";
import ReactCountryFlag from "react-country-flag";
import { useNavigate } from "react-router";


const Navbar = () => {
  // state for mobile dropdown icon
  const [isOpen, setIsOpen] = useState(false);
  // navigation after logout
  const navigate = useNavigate();
  // user authentication state
  const [user, setUser] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("user"));
    } catch {
      return null;
    }
  });

  useEffect(() => {
    const syncUser = () => {
      const token = localStorage.getItem("token");

      try {
        const storedUser = JSON.parse(
          localStorage.getItem("user")
        );

        setUser(token && storedUser ? storedUser : null);
      } catch {
        setUser(null);
      }
    };

    window.addEventListener("storage", syncUser);

    return () => {
      window.removeEventListener("storage", syncUser);
    };
  }, []);

  // logout function
  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");

    setUser(null);
    setIsOpen(false);

    navigate("/", { replace: true });
  };


  const countries = [
    { name: "United States", code: "US", slug: "usa" },
    { name: "United Kingdom", code: "GB", slug: "uk" },
    { name: "Canada", code: "CA", slug: "canada" },
    { name: "Australia", code: "AU", slug: "australia" },
    { name: "Germany", code: "DE", slug: "germany" },
    { name: "Ireland", code: "IE", slug: "ireland" },
    { name: "New Zealand", code: "NZ", slug: "new-zealand" },
    { name: "Netherlands", code: "NL", slug: "netherlands" },
    { name: "Italy", code: "IT", slug: "italy" },
    { name: "France", code: "FR", slug: "france" },
    { name: "Sweden", code: "SE", slug: "sweden" },
    { name: "Switzerland", code: "CH", slug: "switzerland" },
    { name: "China", code: "CN", slug: "china" },
    { name: "Japan", code: "JP", slug: "japan" },
    { name: "South Korea", code: "KR", slug: "south-korea" },
    { name: "Malaysia", code: "MY", slug: "malaysia" },
  ];

  const courseCategories = [
    {
      title: "Engineering & Technology",
      items: [
        {
          name: "Computer Science",
          slug: "computer-science",
        },
        {
          name: "Software Engineering",
          slug: "software-engineering",
        },
        {
          name: "Data Science",
          slug: "data-science",
        },
        {
          name: "Artificial Intelligence",
          slug: "artificial-intelligence",
        },
        {
          name: "Cyber Security",
          slug: "cyber-security",
        },
        {
          name: "Civil Engineering",
          slug: "civil-engineering",
        },
        {
          name: "Mechanical Engineering",
          slug: "mechanical-engineering",
        },
        {
          name: "Electrical Engineering",
          slug: "electrical-engineering",
        },
      ],
    },

    {
      title: "Business & Management",
      items: [
        {
          name: "Business Administration (MBA)",
          slug: "business-administration",
        },
        {
          name: "Finance",
          slug: "finance",
        },
        {
          name: "Accounting",
          slug: "accounting",
        },
        {
          name: "Marketing",
          slug: "marketing",
        },
        {
          name: "Economics",
          slug: "economics",
        },
        {
          name: "International Business",
          slug: "international-business",
        },
      ],
    },

    {
      title: "Health & Medicine",
      items: [
        {
          name: "Medicine",
          slug: "medicine",
        },
        {
          name: "Nursing",
          slug: "nursing",
        },
        {
          name: "Pharmacy",
          slug: "pharmacy",
        },
        {
          name: "Public Health",
          slug: "public-health",
        },
        {
          name: "Dentistry",
          slug: "dentistry",
        },
        {
          name: "Biomedical Science",
          slug: "biomedical-science",
        },
      ],
    },

    {
      title: "Science & Humanities",
      items: [
        {
          name: "Psychology",
          slug: "psychology",
        },
        {
          name: "Law",
          slug: "law",
        },
        {
          name: "Architecture",
          slug: "architecture",
        },
        {
          name: "Environmental Science",
          slug: "environmental-science",
        },
        {
          name: "Biotechnology",
          slug: "biotechnology",
        },
        {
          name: "Media & Communication",
          slug: "media-communication",
        },
      ],
    },
  ];
  return (
    <nav className="fixed inset-x-0 z-50 w-full pt-1 px-2">
      <div className="flex w-full xl:w-[90%] mx-auto px-2 py-2 md:px-3 md:py-3 items-center justify-between rounded-2xl
    border border-white/20
    bg-white/40
    backdrop-blur-md
    backdrop-saturate-150
    shadow-[0_8px_32px_rgba(0,0,0,0.08)]">
        {/* logo and name */}
        <div className="">
          <NavLink
            to="/"
            className="btn btn-ghost gap-2 px-2 text-2xl font-bold"
          >
            <img
              className="h-7 w-7"
              src="https://img.icons8.com/?size=100&id=yk4uIl5Ci0uA&format=png&color=0284C7"
              alt="ScholarX logo"
            />

            <span className="font-[Outfit] tracking-tight">
              Scholar<span className="text-sky-500">X</span>
            </span>
          </NavLink>
        </div>
        {/*desktop center navigation */}
        <div className=" hidden xl:flex">
          <ul className="menu menu-horizontal">
            <li><NavLink to="/" className={({ isActive }) =>
              isActive
                ? "text-sky-600 font-semibold"
                : "text-gray-800 hover:text-sky-600"
            }>Home</NavLink></li>
            <li><NavLink to="/features" className={({ isActive }) =>
              isActive
                ? "text-sky-600 font-semibold"
                : "text-gray-800 hover:text-sky-600"
            }>Features</NavLink></li>
            {/* countries */}
            <li className="relative group">
              <button className="flex items-center gap-1 px-4 py-2 text-gray-800 hover:text-sky-600">
                Countries
                <ChevronDown className="w-4 h-4 group-hover:rotate-180 transition-transform" />
              </button>

              <div
                className="
      absolute flex flex-col left-1/2 top-full
      -translate-x-1/2 mt-4
      w-fit
      min-w-100
      rounded-2xl
      bg-white
      border
      border-gray-200
      shadow-lg
      p-8
      opacity-0 invisible
      group-hover:opacity-100
      group-hover:visible
      transition-all duration-200
      z-50
    "
              >
                <div className="grid grid-cols-2 gap-x-8 gap-y-4">
                  {countries.map((country) => (
                    <NavLink
                      key={country.slug}
                      to={`/countries/${country.slug}`}
                      className="flex items-center gap-3 rounded-lg px-3 py-2 hover:bg-sky-50 transition"
                    >
                      {/* country flag */}
                      <div className="w-7 h-7 rounded-full shadow-xl border border-gray-100 overflow-hidden flex items-center justify-center">
                        <ReactCountryFlag
                          countryCode={country.code}
                          svg
                          style={{
                            width: "100%",
                            height: "100%",
                            objectFit: "cover",
                          }}
                        />
                      </div>
                      {/* country name */}
                      <span>{country.name}</span>
                    </NavLink>
                  ))}
                </div>
                <NavLink
                  to="/countries"
                  className="flex items-center justify-center w-full rounded-xl border border-gray-200 px-5 py-3 font-semibold transition-all duration-300 hover:bg-sky-500 hover:text-white"
                >
                  Explore All

                  <ArrowRight
                    size={18}
                    className="transition-transform duration-300 group-hover:translate-x-1"
                  />
                </NavLink>
              </div>
            </li>
            {/* courses */}
            <li className="relative group">
              <button className="flex items-center gap-1 px-4 py-2 text-gray-800 hover:text-sky-600">
                Programs
                <ChevronDown className="w-4 h-4 transition-transform group-hover:rotate-180" />
              </button>

              <div
                className="
      absolute left-1/2 top-full
      -translate-x-1/2 mt-4
      w-fit flex flex-col
      min-w-100
      rounded-2xl
      bg-white
      border
      border-gray-200
      shadow-lg
      p-8
      opacity-0 invisible
      group-hover:opacity-100
      group-hover:visible
      transition-all duration-200
      z-50
    "
              >
                <div className="grid grid-cols-2 gap-x-8 gap-y-4">
                  {courseCategories.map((category) => (
                    <div key={category.title}>
                      <h3 className="font-semibold text-sky-600 mb-3">
                        {category.title}
                      </h3>

                      <div className="space-y-2">
                        {category.items.map((course) => (
                          <NavLink
                            key={course}
                            to={`/programDetails/${course.slug}`}
                            className="block rounded-lg px-2 py-1 hover:bg-sky-50"
                          >
                            {course.name}
                          </NavLink>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
                <NavLink
                  to="programs"
                  className="flex items-center justify-center w-full rounded-xl border border-gray-200 px-5 py-3 font-semibold transition-all duration-300 hover:bg-sky-500 hover:text-white"
                >
                  Explore All

                  <ArrowRight
                    size={18}
                    className="transition-transform duration-300 group-hover:translate-x-1"
                  />
                </NavLink>
              </div>
            </li>
            <li><NavLink to="/opportunities" className={({ isActive }) =>
              isActive
                ? "text-sky-600 font-semibold"
                : "text-gray-800 hover:text-sky-600"
            }>Opportunities</NavLink></li>
            <li><NavLink to="/pricing" className={({ isActive }) =>
              isActive
                ? "text-sky-600 font-semibold"
                : "text-gray-800 hover:text-sky-600"
            }>Pricing</NavLink></li>
            <li>
              <details>
                <summary>Resources</summary>
                <ul className="p-2 bg-base-100 w-40 z-1">
                  <li><NavLink to="/blog" className={({ isActive }) =>
                    isActive
                      ? "text-sky-600 font-semibold"
                      : "text-gray-700 hover:text-sky-600"
                  }>Blog</NavLink></li>
                  <li><NavLink to="/FAQ" className={({ isActive }) =>
                    isActive
                      ? "text-sky-600 font-semibold"
                      : "text-gray-700 hover:text-sky-600"
                  }>FAQ</NavLink></li>
                  <li><NavLink to="/support" className={({ isActive }) =>
                    isActive
                      ? "text-sky-600 font-semibold"
                      : "text-gray-700 hover:text-sky-600"
                  }>Support</NavLink></li>
                  <li><NavLink to="/about-us" className={({ isActive }) =>
                    isActive
                      ? "text-sky-600 font-semibold"
                      : "text-gray-700 hover:text-sky-600"
                  }>About us</NavLink></li>
                  <li><NavLink to="/contact" className={({ isActive }) =>
                    isActive
                      ? "text-sky-600 font-semibold"
                      : "text-gray-700 hover:text-sky-600"
                  }>Contact</NavLink></li>
                </ul>
              </details>
            </li>
          </ul>
        </div>
        {/* user actions */}
        <div className="flex items-center gap-2">

          
{!user && (
  <>
    <NavLink
      to="/logIn"
      className="
        shrink-0 whitespace-nowrap rounded-lg
        border border-[#3A2C2C]
        bg-gray-100 text-black
        px-2 py-1 text-sm
        shadow-[1px_2px_0px_0px_#3A2C2C]
        transition-all duration-200
        hover:translate-y-0.5
        hover:shadow-[1px_1px_0px_0px_#3A2C2C]
        sm:rounded-xl sm:px-3 sm:py-1.5 sm:text-base
        lg:py-2
      "
    >
      Log in
    </NavLink>

    <NavLink
      to="/register"
      className="
        shrink-0 whitespace-nowrap rounded-lg
        border border-[#3A2C2C]
        bg-[#DCEEFF] text-black
        px-2 py-1 text-sm
        shadow-[1px_2px_0px_0px_#3A2C2C]
        transition-all duration-200
        hover:translate-y-0.5
        hover:shadow-[1px_1px_0px_0px_#3A2C2C]
        sm:rounded-xl sm:px-3 sm:py-1.5 sm:text-base
        lg:py-2
      "
    >
      Sign up
    </NavLink>
  </>
)}


          {/* Desktop profile dropdown */}
          {user && (
            <div className="dropdown dropdown-end hidden xl:block">

              <button
                type="button"
                tabIndex={0}
                aria-label="Open profile menu"
                className="group flex items-center gap-1.5 rounded-full border border-sky-200/80 bg-white/80 p-1.5 pr-2 shadow-sm transition-all duration-300 hover:border-sky-400 hover:bg-sky-50 hover:shadow-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400 focus-visible:ring-offset-2"
              >
                <span className="flex h-9 w-9 items-center justify-center rounded-full bg-linear-to-br from-sky-500 to-blue-600 text-white shadow-sm transition-transform duration-300">
                  <UserRound size={19} strokeWidth={2} />
                </span>

                <ChevronDown
                  size={16}
                  className="text-slate-500 transition-transform duration-200 group-hover:text-sky-600 group-focus:rotate-180"
                />
              </button>


              <ul
                tabIndex={0}
                className="dropdown-content menu z-50 mt-3 w-64 rounded-2xl border border-slate-100 bg-white p-2 shadow-xl"
              >
                {/* User information */}
                <li className="pointer-events-none mb-1 border-b border-slate-100 px-3 py-3">
                  <span className="block truncate font-semibold text-slate-800">
                    {user.name || "ScholarX User"}
                  </span>
                  {user.email && (
                    <span className="block truncate text-xs text-slate-500">
                      {user.email}
                    </span>
                  )}
                </li>

                {/* Dashboard */}
                <li>
                  <NavLink
                    to="/dashboard"
                    onClick={() => setIsOpen(false)}
                    className="font-semibold bg-linear-to-r from-blue-400 via-indigo-500 to-sky-400 bg-clip-text text-transparent hover:text-sky-600"

                  >
                    Dashboard
                  </NavLink>
                </li>

                {/* Logout */}
                <li className="mt-1 border-t border-slate-100 pt-2">
                  <button
                    type="button"
                    onClick={handleLogout}
                    className="flex w-full items-center gap-3 rounded-xl py-2.5 text-red-600 transition-colors bg-red-100 hover:bg-red-500 hover:text-white"
                  >
                    <LogOut size={18} />
                    Log out
                  </button>
                </li>
              </ul>
            </div>
          )}

          {/* mobile dropdown */}
          <div className="relative xl:hidden">

            <button

              onClick={() => setIsOpen(prev => !prev)}

              className="btn btn-ghost"

            >

              {isOpen ? <X size={24} /> : <Menu size={24} />}

            </button>



            {isOpen && (

              <ul
                className="
    absolute right-0 mt-2 sm:mt-3
    menu
    w-64
    max-h-[calc(100vh-350px)]
    flex-nowrap
    overflow-y-auto
    overflow-x-hidden
    rounded-2xl
    bg-base-100
    shadow-xl
    z-100
  "
                onClick={(e) => {
                  if (e.target.closest("a")) {
                    setIsOpen(false);
                  }
                }}
              >

                {user && (
                  <>
                    <li>
                      <NavLink
                        to="/dashboard"
                        onClick={() => setIsOpen(false)}
                        className={({ isActive }) =>
                          isActive
                            ? "text-sky-600 font-bold"
                            : "font-semibold bg-linear-to-r from-blue-400 via-indigo-500 to-sky-400 bg-clip-text text-transparent hover:text-sky-600"
                        }
                      >
                        Dashboard
                      </NavLink>
                    </li>
                  </>
                )}

                <li><NavLink to="/" className={({ isActive }) =>
                  isActive
                    ? "text-sky-600 font-semibold"
                    : "text-gray-700 hover:text-sky-600"
                }>Home</NavLink></li>

                <li><NavLink to="/features" className={({ isActive }) =>
                  isActive
                    ? "text-sky-600 font-semibold"
                    : "text-gray-700 hover:text-sky-600"
                }>Features</NavLink></li>
                {/* countries */}
                <li><NavLink to="/countries" className={({ isActive }) =>
                  isActive
                    ? "text-sky-600 font-semibold"
                    : "text-gray-700 hover:text-sky-600"
                }>Countries</NavLink>
                  <ul className="p-2">
                    {countries.slice(0, 3).map((country) => (
                      <li key={country.slug}>
                        <NavLink
                          to={`/countries/${country.slug}`}
                          className={({ isActive }) =>
                            `flex items-center gap-3 ${isActive
                              ? "text-sky-600 font-semibold"
                              : "text-gray-700 hover:text-sky-600"
                            }`
                          }
                        >
                          <div className="w-6 h-6 rounded-full border shadow-xl border-gray-200 overflow-hidden shrink-0">
                            <ReactCountryFlag
                              countryCode={country.code}
                              svg
                              style={{
                                width: "100%",
                                height: "100%",
                                objectFit: "cover",
                              }}
                            />
                          </div>

                          <span>{country.name}</span>
                        </NavLink>
                      </li>
                    ))}

                    <li>
                      <NavLink
                        to="/countries"
                        className={({ isActive }) =>
                          `group flex items-center gap-2 transition ${isActive
                            ? "text-sky-600 font-semibold"
                            : "text-gray-800 font-medium hover:text-sky-600"
                          }`
                        }
                      >
                        View All
                        <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                      </NavLink>
                    </li>
                  </ul>
                </li>
                {/* programs */}
                <li><NavLink to="/programs" className={({ isActive }) =>
                  isActive
                    ? "text-sky-600 font-semibold"
                    : "text-gray-700 hover:text-sky-600"
                }>Programs</NavLink>
                  <ul className="p-2">

                    <li><NavLink to="/programDetails/business-administration" className={({ isActive }) =>
                      isActive
                        ? "text-sky-600 font-semibold"
                        : "text-gray-700 hover:text-sky-600"
                    }>Business Administration</NavLink></li>

                    <li><NavLink to="/programDetails/computer-science" className={({ isActive }) =>
                      isActive
                        ? "text-sky-600 font-semibold"
                        : "text-gray-700 hover:text-sky-600"
                    }>Computer Science</NavLink></li>

                    <li><NavLink to="/programDetails/nursing" className={({ isActive }) =>
                      isActive
                        ? "text-sky-600 font-semibold"
                        : "text-gray-700 hover:text-sky-600"
                    }>Nursing</NavLink></li>
                    <li><NavLink to="/programs" className={({ isActive }) =>
                      isActive
                        ? "text-sky-600 font-semibold group flex items-center gap-2 transition"
                        : "text-gray-800 font-medium group flex items-center gap-2 transition hover:text-sky-600"
                    }>View All <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" /></NavLink></li>

                  </ul>
                </li>

                <li><NavLink to="/opportunities" className={({ isActive }) =>
                  isActive
                    ? "text-sky-600 font-semibold"
                    : "text-gray-700 hover:text-sky-600"
                }>Opportunities</NavLink ></li>

                <li><NavLink to="/pricing" className={({ isActive }) =>
                  isActive
                    ? "text-sky-600 font-semibold"
                    : "text-gray-700 hover:text-sky-600"
                }>Pricing</NavLink ></li>

                <li>

                  <Link className="text-gray-700 hover:text-sky-600"
                  >Resources</Link>

                  <ul className="p-2">

                    <li><NavLink to="/blog" className={({ isActive }) =>
                      isActive
                        ? "text-sky-600 font-semibold"
                        : "text-gray-700 hover:text-sky-600"
                    }>Blog</NavLink></li>

                    <li><NavLink to="/FAQ" className={({ isActive }) =>
                      isActive
                        ? "text-sky-600 font-semibold"
                        : "text-gray-700 hover:text-sky-600"
                    }>FAQ</NavLink></li>

                    <li><NavLink to="/support" className={({ isActive }) =>
                      isActive
                        ? "text-sky-600 font-semibold"
                        : "text-gray-700 hover:text-sky-600"
                    }>Support</NavLink></li>

                    <li><NavLink to="/about-us" className={({ isActive }) =>
                      isActive
                        ? "text-sky-600 font-semibold"
                        : "text-gray-700 hover:text-sky-600"
                    }>About us</NavLink></li>

                    <li><NavLink to="/contact" className={({ isActive }) =>
                      isActive
                        ? "text-sky-600 font-semibold"
                        : "text-gray-700 hover:text-sky-600"
                    }>Contact</NavLink></li>
                  </ul>

                  {user && (
                    <>
                      <li className="mt-1 border-t border-gray-100 pt-3">
                        <button
                          type="button"
                          onClick={handleLogout}
                          className="flex w-full items-center justify-center gap-3 rounded-lg px-3 py-2.5 font-medium text-red-600 transition-all duration-300 bg-red-100 hover:bg-red-500 hover:text-white"
                        >
                          <LogOut size={18} strokeWidth={2} />
                          <span>Log out</span>
                        </button>
                      </li>
                    </>
                  )}
                </li>
              </ul>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;