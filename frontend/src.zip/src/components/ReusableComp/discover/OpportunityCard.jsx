import {
  ArrowRight,
  CalendarDays,
  CircleDollarSign,
  Globe2,
  GraduationCap,
  Landmark,
} from "lucide-react";
import { NavLink } from "react-router";

const formatCategory = (value) => {
  if (!value) return "Scholarship";

  const words = value.trim().split(/\s+/);

  const formattedWords = words
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(" ");

  return words.length === 1 ? `${formattedWords} Scholarship ` : formattedWords;
};

const OpportunityCard = ({ opportunity }) => {
  const isDatabaseScholarship = opportunity.source === "database";

  const hasTuitionCoverage = opportunity.coverage?.some(
    (item) => item.benefit_type === "tuition_fee",
  );

  const hasAccommodationCoverage = opportunity.coverage?.some(
    (item) => item.benefit_type === "accommodation",
  );

  const isFullyFunded =
    isDatabaseScholarship && hasTuitionCoverage && hasAccommodationCoverage;

  const fundingLabel = isDatabaseScholarship
    ? isFullyFunded
      ? "Fully Funded"
      : "Partial Funding"
    : opportunity.funding;
  // Normalize fields from both data sources
  const provider = isDatabaseScholarship
    ? "ScholarX Scholarship"
    : opportunity.provider;

  const category = isDatabaseScholarship
    ? opportunity.scholarship_type || "Scholarship"
    : opportunity.category;

  const deadline = isDatabaseScholarship
    ? opportunity.last_date_to_apply || "Not specified"
    : opportunity.deadline;

  const detailsLink = isDatabaseScholarship
    ? `/opportunityDetails/${opportunity.databaseId}`
    : `/opportunityDetails/${opportunity.slug}`;

  return (
    <div
      className="
        group h-full flex flex-col relative overflow-hidden
        rounded-3xl
        border border-sky-100
        bg-white
        p-6
        shadow-[0_8px_30px_rgba(14,165,233,0.06)]
        transition-all duration-300
        hover:-translate-y-1
        hover:border-sky-200
        hover:shadow-[0_18px_45px_rgba(14,165,233,0.14)]
      "
    >
      {/* Decorative glow */}
      <div
        className="
          pointer-events-none
          absolute -right-16 -top-16
          h-36 w-36
          rounded-full
          bg-sky-100/60
          blur-3xl
          transition-all duration-500
          group-hover:bg-sky-200/70
        "
      />

      <div className="relative z-10 flex flex-1 flex-col">
        {/* Header */}
<div className="flex items-start gap-3">

  {/* Opportunity Icon + Title */}
  <div className="flex min-w-0 flex-1 items-start gap-3">

    {/* Icon */}
    <div
      className="
        flex h-12 w-12 shrink-0
        items-center justify-center
        rounded-2xl
        border border-sky-100
        bg-sky-50
        text-sky-600
        transition-all duration-300
        group-hover:bg-sky-600
        group-hover:text-white
        group-hover:scale-105
      "
    >
      <GraduationCap className="h-6 w-6" />
    </div>

    {/* Title + Provider */}
    <div className="min-w-0 flex-1">
      <h2
        className="
          text-xl font-bold
          leading-snug
          tracking-tight
          text-gray-900
          transition-colors
          group-hover:text-sky-700
        "
      >
        {opportunity.title}
      </h2>

      <div className="mt-1.5 flex items-center gap-1.5 text-sm text-gray-500">
        <Landmark className="h-3.5 w-3.5 shrink-0 text-sky-500" />
        <span className="truncate">{provider}</span>
      </div>
    </div>
  </div>

  {/* Category */}
  <span
    className="
      hidden sm:inline-flex
      max-w-30 shrink-0
      items-center justify-center
      rounded-full
      border border-sky-100
      bg-sky-50
      px-3 py-1.5
      text-center text-xs font-semibold
      leading-tight
      text-sky-700
      whitespace-normal
    "
  >
    {formatCategory(category)}
  </span>
</div>

        {/* Mobile category */}
        <span
          className="
            mt-3 inline-flex sm:hidden
            rounded-full
            border border-sky-100
            bg-sky-50
            px-3 py-1.5
            text-xs font-semibold
            text-sky-700
          "
        >
          {category}
        </span>

        {/* Divider */}
        <div className="my-5 h-px bg-gray-100" />

        {/* Location */}
        <div
          className="
            flex items-center gap-3
            rounded-2xl
            border border-gray-100
            bg-gray-50/70
            px-4 py-3
            transition-all duration-300
            group-hover:border-sky-100
            group-hover:bg-sky-50/40
          "
        >
          <div
            className="
              flex h-9 w-9 shrink-0
              items-center justify-center
              rounded-xl
              bg-white
              text-sky-600
              shadow-sm
            "
          >
            <Globe2 className="h-4 w-4" />
          </div>

          <div>
            <p className="text-[11px] text-gray-400">Study Destination</p>

            <p className="text-sm font-semibold text-gray-800">
              {opportunity.country || "Not specified"}
            </p>
          </div>
        </div>

        {/* Funding + Deadline */}
<div className="my-3 grid grid-cols-2 gap-3">

  {/* Funding */}
  <div
    className="
      rounded-2xl
      border border-gray-100
      bg-gray-50/70
      p-3.5
      transition-all duration-300
      group-hover:border-sky-100
      group-hover:bg-sky-50/40
    "
  >
    {/* Icon + Label */}
    <div className="flex items-center gap-2">
      <CircleDollarSign className="h-4 w-4 shrink-0 text-emerald-600" />
      <p className="text-xs font-medium text-gray-500">Funding</p>
    </div>

    {/* Value */}
    <p className="mt-2 text-sm font-bold leading-snug text-gray-900">
      {fundingLabel}
    </p>
  </div>

  {/* Deadline */}
  <div
    className="
      rounded-2xl
      border border-gray-100
      bg-gray-50/70
      p-3.5
      transition-all duration-300
      group-hover:border-sky-100
      group-hover:bg-sky-50/40
    "
  >
    {/* Icon + Label */}
    <div className="flex items-center gap-2">
      <CalendarDays className="h-4 w-4 shrink-0 text-orange-500" />
      <p className="text-xs font-medium text-gray-500">Deadline</p>
    </div>

    {/* Value */}
    <p className="mt-2 text-sm font-bold leading-snug text-gray-900">
      {deadline}
    </p>
  </div>

</div>

        {/* CTA */}
        <NavLink
          to={detailsLink}
          className="
            group/link
            mt-auto
            flex w-full
            items-center justify-between
            rounded-2xl
            border border-sky-100
            bg-sky-50
            px-4 py-3
            text-sm font-semibold
            text-sky-700
            transition-all duration-300
            hover:border-sky-200
            hover:bg-sky-100
            hover:text-sky-800
          "
        >
          <span>View Opportunity</span>

          <span
            className="
              flex h-8 w-8
              items-center justify-center
              rounded-xl
              bg-white
              text-sky-600
              shadow-sm
              transition-transform duration-300
              group-hover/link:translate-x-1
            "
          >
            <ArrowRight className="h-4 w-4" />
          </span>
        </NavLink>
      </div>
    </div>
  );
};

export default OpportunityCard;
